# Venkat Priyan S — Portfolio Website

## Preview
Open `index.html` in a browser.

## Before publishing
- Verify your course year and expected graduation date.
- Verify the certification title, issuer, and credential URL.
- Add GitHub repository URLs to each completed project.
- Replace planned project descriptions with actual work after completing them.
- Add a professional email address if you want employers to contact you directly.

## Publish for free with GitHub Pages
1. Create a GitHub repository named `venkat24060606.github.io` (or another repository).
2. Upload `index.html` to the repository root.
3. Open repository Settings → Pages.
4. Select deploy from the main branch and root folder, then save.
5. Wait for GitHub Pages to publish the site.

The site is responsive and uses plain HTML/CSS/JavaScript. Google Fonts require an internet connection; the page remains usable without them.
